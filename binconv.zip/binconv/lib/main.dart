import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Binary Calculator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color.fromARGB(255, 15, 46, 7),
        ),
      ),
      home: const MyHomePage(title: 'Binary Calculator'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController value1 = TextEditingController();
  String selectedInputBase = 'Decimal';
  final List<String> baseOptions = [
    'Binary',
    'Decimal',
    'Octal',
    'Hexadecimal',
  ];
  String resultb = '';

  void clear() {
    setState(() {
      resultb = '';
      value1.clear();
    });
  }

  int? parseInputBasedOnType(String input, String base) {
    try {
      switch (base) {
        case 'Binary':
          return int.parse(input, radix: 2);
        case 'Octal':
          return int.parse(input, radix: 8);
        case 'Hexadecimal':
          return int.parse(input, radix: 16);
        case 'Decimal':
        default:
          return int.parse(input);
      }
    } catch (e) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 13, 48, 14),
        title: Text(
          widget.title,
          style: const TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Container(
          padding: const EdgeInsets.all(15),
          width: 350,
          height: 450,
          decoration: BoxDecoration(
            color: const Color.fromARGB(255, 13, 48, 14),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    buildTextFormField(
                      value1,
                      'Enter a value',
                      'Please insert a value',
                    ),
                  ],
                ),
              ),
              Container(
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 13, 48, 14),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButton<String>(
                  value: selectedInputBase,
                  onChanged: (String? newValue) {
                    setState(() {
                      selectedInputBase = newValue!;
                    });
                  },
                  dropdownColor: const Color.fromARGB(255, 13, 48, 14),
                  style: const TextStyle(color: Colors.white),
                  iconEnabledColor: Colors.white,
                  items:
                      baseOptions.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      }).toList(),
                ),
              ),
              const SizedBox(height: 20),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                alignment: WrapAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          final parsed = parseInputBasedOnType(
                            value1.text.trim(),
                            selectedInputBase,
                          );
                          resultb =
                              parsed != null
                                  ? parsed.toRadixString(2)
                                  : 'Invalid input';
                        });
                      }
                    },
                    child: const Text("To Binary"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          final parsed = parseInputBasedOnType(
                            value1.text.trim(),
                            selectedInputBase,
                          );
                          resultb =
                              parsed != null
                                  ? parsed.toString()
                                  : 'Invalid input';
                        });
                      }
                    },
                    child: const Text("To Decimal"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          final parsed = parseInputBasedOnType(
                            value1.text.trim(),
                            selectedInputBase,
                          );
                          resultb =
                              parsed != null
                                  ? parsed.toRadixString(8)
                                  : 'Invalid input';
                        });
                      }
                    },
                    child: const Text("To Octal"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        setState(() {
                          final parsed = parseInputBasedOnType(
                            value1.text.trim(),
                            selectedInputBase,
                          );
                          resultb =
                              parsed != null
                                  ? parsed.toRadixString(16).toUpperCase()
                                  : 'Invalid input';
                        });
                      }
                    },
                    child: const Text("To Hexadecimal"),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Text(
                'Conversion: $resultb',
                style: const TextStyle(fontSize: 24, color: Colors.white),
              ),
              Spacer(),
              Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                  onPressed: clear,
                  child: const Text("Clear"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextFormField(
    TextEditingController controller,
    String label,
    String emptyMessage,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
          labelStyle: const TextStyle(color: Colors.white),
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(color: Colors.white),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return emptyMessage;
          }
          return null;
        },
        style: const TextStyle(color: Colors.white),
      ),
    );
  }
}
