package com.example.binconv

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
